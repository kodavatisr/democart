<?php
class Notice_Model extends MY_Model {

    public $_table_name;
    public $_order_by;
    public $_primary_key;    
}