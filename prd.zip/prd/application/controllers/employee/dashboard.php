<?php

class Dashboard extends Employee_Controller {

    public function __construct() {

        parent::__construct();
        $this->load->model('emp_model');
		$this->load->model('admin_model');
        $this->load->model('global_model');
        $this->load->model('mailbox_model');
        $this->load->helper('ckeditor');
        $this->data['ckeditor'] = array(
            'id' => 'ck_editor',
            'path' => 'asset/js/ckeditor',
            'config' => array(
                'toolbar' => "Full",
                'width' => "100%",
                'height' => "350px"
            )
        );
    }

    public function index() {
        $data['menu'] = array("index" => 1);
        $data['title'] = "Employee Panel";
        $employee_id = $this->session->userdata('employee_id');


        $this->emp_model->_table_name = "tbl_attendance"; //table name
        $this->emp_model->_order_by = "employee_id";
        $data['total_attendance'] = count($this->total_attendace_in_month($employee_id));
        // get clock in/out time

        $this->emp_model->_table_name = "tbl_attendance"; //table name
        $this->emp_model->_order_by = "employee_id";
        $attendance_info = $this->emp_model->get_by(array('employee_id' => $employee_id,), FALSE);
        foreach ($attendance_info as $v_info) {
            $data['clocking'] = $this->emp_model->check_by(array('attendance_id' => $v_info->attendance_id, 'clocking_status' => 1), 'tbl_clock');
        }

        //get employee details by employee id
        $data['employee_details'] = $this->emp_model->all_emplyee_info($employee_id);
        // upcoming birthday
        $data['employee'] = $this->emp_model->get_upcoming_birthday(); // get resutl
        //Total Attendance
        $this->emp_model->_table_name = "tbl_attendance"; //table name
        $this->emp_model->_order_by = "employee_id";
        $data['total_attendance'] = count($this->total_attendace_in_month($employee_id));
        // get working days holiday
        $holidays = count($this->global_model->get_holidays()); //tbl working Days Holiday
        // get public holiday
        $public_holiday = count($this->total_attendace_in_month($employee_id, TRUE));

        // get total days in a month
        $month = date('m');
        $year = date('Y');
        $days = cal_days_in_month(CAL_GREGORIAN, $month, $year);
        // total attend days in a month without public holiday and working days
        $data['total_days'] = $days - $holidays - $public_holiday;

        //leave applied         
        $data['total_leave_applied'] = $this->get_approved_leave($employee_id);

        //award received
        $this->emp_model->_table_name = "tbl_employee_award"; //table name
        $this->emp_model->_order_by = "employee_id";
        $data['total_award_received'] = count($this->emp_model->get_by(array('employee_id' => $employee_id,), FALSE));

         $this->emp_model->_table_name = "tbl_expense"; //table name
        $this->emp_model->_order_by = "expense_id";
        $data['total_expense_received'] = count($this->emp_model->get_by(array('employee_id' => $employee_id), FALSE));

        //get all notice by flag       
        $data['notice_info'] = $this->emp_model->get_all_notice(TRUE);

        //get all upcomming events
        $data['event_info'] = $this->emp_model->get_all_events();
		
		 $data['today_absent'] = $this->admin_model->get_today_absent();
		 $data['nextweek_absent'] = $this->admin_model->get_nextweek_absent();
		 $data['get_holiday'] = $this->admin_model->check_holiday_by_date();
         $data['leave_employee'] = $this->admin_model->get_leave_employee();
		
        // get recent email                  
        $data['get_inbox_message'] = $this->emp_model->get_inbox_message($this->session->userdata('email'), $flag = NULL, $del_info = NULL, TRUE);
        $data['subview'] = $this->load->view('employee/main_content', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }

    public function get_approved_leave() { }

    public function total_attendace_in_month($employee_id, $flag = NULL) {
        $month = date('m');
        $year = date('Y');

        if ($month >= 1 && $month <= 9) { // if i<=9 concate with Mysql.becuase on Mysql query fast in two digit like 01.
            $start_date = $year . "-" . '0' . $month . '-' . '01';
            $end_date = $year . "-" . '0' . $month . '-' . '31';
        } else {
            $start_date = $year . "-" . $month . '-' . '01';
            $end_date = $year . "-" . $month . '-' . '31';
        }
        if (!empty($flag)) { // if flag is not empty that means get pulic holiday
            $get_public_holiday = $this->emp_model->get_public_holiday($start_date, $end_date);
            if (!empty($get_public_holiday)) { // if not empty the public holiday
                foreach ($get_public_holiday as $v_holiday) {
                    if ($v_holiday->start_date == $v_holiday->end_date) { // if start date and end date is equal return one data
                        $total_holiday[] = $v_holiday->start_date;
                    } else { // if start date and end date not equan return all date
                        for ($j = $v_holiday->start_date; $j <= $v_holiday->end_date; $j++) {
                            $total_holiday[] = $j;
                        }
                    }
                }
                return $total_holiday;
            }
        } else {
            $get_total_attendance = $this->emp_model->get_total_attendace_by_date($start_date, $end_date, $employee_id); // get all attendace by start date and in date 
            return $get_total_attendance;
        }
    }

    public function set_clocking($id = NULL) {

        // sate into attendance table
        $adata['employee_id'] = $this->session->userdata('employee_id');
        $clocktime = $this->input->post('clocktime', TRUE);
        if ($clocktime == 1) {
            $adata['date_in'] = $this->input->post('date', TRUE);
        } else {
            $adata['date_out'] = $this->input->post('date', TRUE);
        }
        if (!empty($adata['date_in'])) {
            // chck existing date is here or not
            $check_date = $this->emp_model->check_by(array('employee_id' => $adata['employee_id'], 'date_in' => $adata['date_in']), 'tbl_attendance');
        }
        if (!empty($check_date)) { // if exis do not save date and return id
            if ($check_date->attendance_status != '1') {
                $udata['attendance_status'] = 1;
                $this->emp_model->_table_name = "tbl_attendance"; // table name        
                $this->emp_model->_primary_key = "attendance_id"; // $id 
                $this->emp_model->save($udata, $check_date->attendance_id);
            }
            $data['attendance_id'] = $check_date->attendance_id;
        } else { // else save data into tbl attendance 
            // get attendance id by clock id into tbl clock 
            // if attendance id exist that means he/she clock in 
            // return the id
            // and update the day out time
            $check_existing_data = $this->emp_model->check_by(array('clock_id' => $id), 'tbl_clock');
            $this->emp_model->_table_name = "tbl_attendance"; // table name        
            $this->emp_model->_primary_key = "attendance_id"; // $id            
            if (!empty($check_existing_data)) {
                $this->emp_model->save($adata, $check_existing_data->attendance_id);
            } else {
                $adata['attendance_status'] = 1;
                //save data into attendance table
                $data['attendance_id'] = $this->emp_model->save($adata);
            }
        }
        // save data into clock table
        if ($clocktime == 1) {
            $data['clockin_time'] = $this->input->post('time', TRUE);
        } else {
            $data['clockout_time'] = $this->input->post('time', TRUE);            
        }
        //save data in database
        $this->emp_model->_table_name = "tbl_clock"; // table name
        $this->emp_model->_primary_key = "clock_id"; // $id
        if (!empty($id)) {
            $data['clocking_status'] = 0;
            $this->emp_model->save($data, $id);
        } else {
            $data['clocking_status'] = 1;
            $this->emp_model->save($data);
        }
        redirect('employee/dashboard');
    }

    public function my_time() {
        $data['title'] = 'My Time Log';
        $data['menu'] = array("my_time" => 1);

        $employee_id = $this->session->userdata('employee_id');
        $this->emp_model->_table_name = "tbl_attendance"; // table name        
        $this->emp_model->_order_by = "employee_id"; // $id
        $attendance_info = $this->emp_model->get_by(array('employee_id' => $employee_id), FALSE);
        $data['mytime_info'] = $this->get_mytime_info($attendance_info);
        $data['active'] = date('Y');
        $data['subview'] = $this->load->view('employee/my_time', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }

    public function get_mytime_info($attendance_info) {
        if (!empty($attendance_info)) {
            foreach ($attendance_info as $v_info) {
                if ($v_info->date_in == $v_info->date_out) {
                    $date = date('d M Y', strtotime($v_info->date_in));
                } else {
                    $date = 'Date In : ' . date('d M Y', strtotime($v_info->date_in)) . ', Date Out : ' . date('d M Y', strtotime($v_info->date_out));
                }
                $clock_info[date('Y', strtotime($v_info->date_in))][date('W', strtotime($v_info->date_in))][$date] = $this->emp_model->get_mytime_info($v_info->attendance_id);
            }
            return $clock_info;
        }
    }

    public function edit_mytime($clock_id) {
        $data['title'] = "Admin Dashboard";
        $attendance_id = NULL;
        $data['clock_info'] = $this->emp_model->get_mytime_info($attendance_id, $clock_id);
        $data['subview'] = $this->load->view('employee/edit_mytime', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }

    public function cheanged_mytime($clock_id) {
        $cdata = $this->emp_model->array_from_post(array('reason', 'clockin_edit', 'clockout_edit'));

        $data['clock_id'] = $clock_id;
        $data['employee_id'] = $this->session->userdata('employee_id');
        $data['clockin_edit'] = date('H:i', strtotime($cdata['clockin_edit']));
        $data['clockout_edit'] = date('H:i', strtotime($cdata['clockout_edit']));
        $data['reason'] = $cdata['reason'];

        //save data in database
        $this->emp_model->_table_name = "tbl_clock_history"; // table name
        $this->emp_model->_order_by = "clock_history_id"; // $id
        $this->emp_model->save($data);
        // messages for user
        $type = "success";
        $message = "Clocking Information Successfully Submitted .Please Wait for admin approval !";
        set_message($type, $message);
        redirect('employee/dashboard/my_time');
    }

    public function payslip() {
        $data['menu'] = array("payslip" => 1);
		
		
        $data['title'] = "Add to cart";
		
        $data['subview'] = $this->load->view('employee/addtocart', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }

 public function checkin() {
        $data['menu'] = array("checkin" => 1);
        $data['title'] = "Check In";
        $data['subview'] = $this->load->view('employee/checkin', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }

    public function salary_payment_details($salary_payment_id) {
        $data['title'] = "Manage Salery Details";
        $data['page_header'] = "Payroll Management";
        $data['salary_payment_info'] = $this->emp_model->get_salary_payment_info($salary_payment_id);
        $data['subview'] = $this->load->view('employee/salary_payment_details', $data, FALSE);
        $this->load->view('admin/_layout_modal_lg', $data);
    }

    public function expense($id = NULL) {
        $data['title'] = 'My expense';
        $data['menu'] = array("expense" => 1);
        $this->session->userdata('employee_id');
        if (!empty($id)) {
            $data['active'] = 2;
        } else {
            $data['active'] = 1;
        }
        $data['subview'] = $this->load->view('employee/my_expense', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }

    public function save_expense($id = NULL) { }

    public function my_task($id = NULL) {
        $data['title'] = 'My Task';
        $data['menu'] = array("my_task" => 1);
        if (!empty($id)) {
            $data['active'] = 2;
        } else {
            $data['active'] = 1;
        }
        $data['subview'] = $this->load->view('employee/my_task', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }

    public function save_comments() {

        $data['task_id'] = $this->input->post('task_id', TRUE);
        $data['comment'] = $this->input->post('comment', TRUE);
        $user_type = $this->session->userdata('user_type');
        if ($user_type == 1) {
            $data['user_id'] = $this->session->userdata('employee_id');
        } else {
            $data['employee_id'] = $this->session->userdata('employee_id');
        }
        //save data into table.
        $this->emp_model->_table_name = "tbl_task_comment"; // table name
        $this->emp_model->_primary_key = "task_comment_id"; // $id
        $this->emp_model->save($data);

        $type = "success";
        $message = "Task Successfully Updated!";
        set_message($type, $message);
        redirect('employee/dashboard/view_task_details/' . $data['task_id'] . '/' . $data['active'] = 2);
    }

    public function save_task_attachment($task_attachment_id = NULL) {
        $data = $this->emp_model->array_from_post(array('title', 'description', 'task_id'));
        $user_type = $this->session->userdata('user_type');
        if ($user_type == 1) {
            $data['user_id'] = $this->session->userdata('employee_id');
        } else {
            $data['employee_id'] = $this->session->userdata('employee_id');
        }
        // save and update into tbl_files
        $this->emp_model->_table_name = "tbl_task_attachment"; //table name
        $this->emp_model->_primary_key = "task_attachment_id";
        if (!empty($task_attachment_id)) {
            $id = $task_attachment_id;
            $this->emp_model->save($data, $id);
            $msg = lang('task_file_updated');
        } else {
            $id = $this->emp_model->save($data);
            $msg = lang('task_file_added');
        }

        if (!empty($_FILES['task_files']['name']['0'])) {
            $old_path_info = $this->input->post('uploaded_path');
            if (!empty($old_path_info)) {
                foreach ($old_path_info as $old_path) {
                    unlink($old_path);
                }
            }
            $mul_val = $this->emp_model->multi_uploadAllType('task_files');

            foreach ($mul_val as $val) {
                $val == TRUE || redirect('employee/dashboard/view_task_details/3/' . $data['task_id']);
                $fdata['files'] = $val['path'];
                $fdata['file_name'] = $val['fileName'];
                $fdata['uploaded_path'] = $val['fullPath'];
                $fdata['size'] = $val['size'];
                $fdata['ext'] = $val['ext'];
                $fdata['is_image'] = $val['is_image'];
                $fdata['image_width'] = $val['image_width'];
                $fdata['image_height'] = $val['image_height'];
                $fdata['task_attachment_id'] = $id;
                $this->emp_model->_table_name = "tbl_task_uploaded_files"; // table name
                $this->emp_model->_primary_key = "uploaded_files_id"; // $id
                $this->emp_model->save($fdata);
            }
        }
        // messages for user
        $type = "success";
        $message = $msg;
        set_message($type, $message);
        redirect('employee/dashboard/view_task_details/' . $data['task_id'] . '/3');
    }

    public function view_task_details($id, $active = NULL) {
        $data['title'] = "Task Details";
        $data['page_header'] = "Task Management";

        //get all task information
        $data['task_details'] = $this->emp_model->get_all_task_info($id);
        //get all comments info
        $data['comment_details'] = $this->emp_model->get_all_comment_info($id);

        $this->emp_model->_table_name = "tbl_task_attachment"; //table name
        $this->emp_model->_order_by = "task_id";
        $data['files_info'] = $this->emp_model->get_by(array('task_id' => $id), FALSE);

        foreach ($data['files_info'] as $key => $v_files) {
            $this->emp_model->_table_name = "tbl_task_uploaded_files"; //table name
            $this->emp_model->_order_by = "task_attachment_id";
            $data['project_files_info'][$key] = $this->emp_model->get_by(array('task_attachment_id' => $v_files->task_attachment_id), FALSE);
        }

        if ($active == 2) {
            $data['active'] = 2;
        } elseif ($active == 3) {
            $data['active'] = 3;
        } else {
            $data['active'] = 1;
        }

        $data['subview'] = $this->load->view('employee/view_task', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }

    public function download_files($task_id, $uploaded_files_id) {
        $this->load->helper('download');
        $uploaded_files_info = $this->emp_model->check_by(array('uploaded_files_id' => $uploaded_files_id), 'tbl_task_uploaded_files');

        if ($uploaded_files_info->uploaded_path) {
            $data = file_get_contents($uploaded_files_info->uploaded_path); // Read the file's contents            
            force_download($uploaded_files_info->file_name, $data);
        } else {
            $type = "success";
            $message = lang('operation_failed');
            set_message($type, $message);
            redirect('employee/dashboard/view_task_details/' . $task_id . '/3');
        }
    }

    public function leave_application() {
        $data['menu'] = array("leave_application" => 1);
        $data['title'] = "Employee Panel";
        $data['active'] = 1;
        //get leave category for dropdown
        $this->emp_model->_table_name = "tbl_leave_category"; // table name
        $this->emp_model->_order_by = "leave_category_id"; // $id
        $data['all_leave_category'] = $this->emp_model->get(); // get result
        //get leave applied with category name
        $employee_id = $this->session->userdata('employee_id');
        $data['all_leave_applications'] = $this->emp_model->get_all_leave_applied($employee_id);
        $data['subview'] = $this->load->view('employee/emp_leave_application', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }
  public function edit_leave_application($id) {
 // echo $id;
        $data['menu'] = array("leave_application" => 1);
        $data['title'] = "Employee Panel";
        $data['active'] = 1;
        //get leave category for dropdown
		  $this->emp_model->_table_name = "tbl_application_list"; // table name
         $this->emp_model->_order_by = "application_list_id desc"; // $id
		 //array('employee_id' => $this->session->userdata('employee_id') ,
        $data['leave_application_det']  = $this->emp_model->get_by(array('employee_id' => $this->session->userdata('employee_id'), 'application_list_id' =>$id), FALSE);
		//print_r($leave_application_det);
        $this->emp_model->_table_name = "tbl_leave_category"; // table name
        $this->emp_model->_order_by = "leave_category_id"; // $id
        $data['all_leave_category'] = $this->emp_model->get(); // get result
        //get leave applied with category name
        $employee_id = $this->session->userdata('employee_id');
        $data['all_leave_applications'] = $this->emp_model->get_all_leave_applied($employee_id);
        $data['subview'] = $this->load->view('employee/edit_emp_leave_application', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }
	  public function edit_save_leave_application() {
	   $this->emp_model->_table_name = "tbl_application_list"; // table name
        $this->emp_model->_primary_key = "application_list_id"; // $id
	   //$data['employee_id'] = $this->session->userdata('employee_id');
	   //  $data['leave_category_id'] = $this->input->post('application_list_id');
	    if (!empty($_FILES['upload_file']['name'])) {

                    $val = $this->emp_model->uploadAllType('upload_file');
                    $val == TRUE || redirect('employee/dashboard/apply_leave_application');
                    $data['filename'] = $val['fileName'];
                    $data['upload_file'] = $val['path'];
                }
                     $this->emp_model->_table_name = 'tbl_application_list';
                    $this->emp_model->_primary_key = "application_list_id";
                   // $this->emp_model->save($data, $this->input->post('application_list_id'));
					  $app_id =$this->input->post('application_list_id');
           // $data['status'] = $this->input->post('status', TRUE);
            $this->emp_model->save($data,$app_id);
	  
                $type = "success";
                $message = "eLeave Updated successfully";
				set_message($type, $message);
redirect('employee/dashboard/leave_application');
	  }
	
	
	
	
	
    public function save_leave_application() { }

    function check_available_leave($employee_id, $start_date = NULL, $end_date = NULL, $leave_category_id = NULL) { }

    public function all_notice() {
        $data['menu'] = array("notice" => 1);
        $data['title'] = "All Notice";

        // get all notice by flag       
        $data['notice_info'] = $this->emp_model->get_all_notice();

        $data['subview'] = $this->load->view('employee/all_notice', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }

    public function notice_detail($id) {
        $data['title'] = "Notice Details";

        //get leave category for dropdown
        $this->emp_model->_table_name = "tbl_notice"; // table name
        $this->emp_model->_order_by = "notice_id"; // $id
        $data['full_notice_details'] = $this->emp_model->get_by(array('notice_id' => $id,), TRUE); // get result

        $data['modal_subview'] = $this->load->view('employee/notice_details', $data, FALSE);
        $this->load->view('admin/_layout_modal_lg', $data);
    }

    public function all_events() {
        $data['menu'] = array("events" => 1);
        $data['title'] = "All Events";

        // get all notice by flag       
        $data['event_info'] = $this->emp_model->get_all_events();

        $data['subview'] = $this->load->view('employee/events', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }

    public function event_detail($id) {
        $data['title'] = "Event Details";

        //get leave category for dropdown
        $this->emp_model->_table_name = "tbl_holiday"; // table name
        $this->emp_model->_order_by = "holiday_id"; // $id
        $data['event_details'] = $this->emp_model->get_by(array('holiday_id' => $id,), TRUE); // get result

        $data['subview'] = $this->load->view('employee/event_details', $data, FALSE);
        $this->load->view('admin/_layout_modal', $data);
    }

    public function all_award() {
        $data['menu'] = array("awards" => 1);
        $data['title'] = "All Awards";

        // get all notice by flag       
        $data['award_info'] = $this->emp_model->get_all_awards();

        $data['subview'] = $this->load->view('employee/all_awards', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }

    public function award_detail($id) {
        $data['title'] = "All Awards";

        //get award detail info for particular employee    
        $data['employee_award_info'] = $this->emp_model->get_all_awards($id);

        $data['subview'] = $this->load->view('employee/award_details_page', $data, FALSE);
        $this->load->view('admin/_layout_modal', $data);
    }

    public function job_circular($id = NULL) {
        $data['title'] = "Job Circular";
        $data['menu'] = array("job_circular" => 1);
        //get leave category for dropdown
        $this->emp_model->_table_name = "tbl_job_circular"; // table name
        $this->emp_model->_order_by = "job_circular_id"; // $id
        if (!empty($id)) {
            $data['job_circular'] = $this->emp_model->get_by(array('job_circular_id' => $id,), TRUE); // get result                    
        }
        $data['job_circular_info'] = $this->emp_model->get_by(array('status' => 1,), FALSE); // get result                
        $data['subview'] = $this->load->view('employee/job_circular', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }

    public function save_job_application($id) {
        $data = $this->emp_model->array_from_post(array('name', 'email', 'mobile', 'cover_letter'));
        // Resume File upload
        if (!empty($_FILES['resume']['name'])) {
            $val = $this->emp_model->uploadFile('resume');
            $val == TRUE || redirect('employee/dashboard/job_circular');
            $data['resume'] = $val['path'];
        }
        $data['job_circular_id'] = $id;
        $data['employee_id'] = $this->session->userdata('employee_id');
        $where = array('job_circular_id' => $id, 'employee_id' => $data['employee_id']);
        $check_existing_data = $this->emp_model->check_by($where, 'tbl_job_appliactions');
        if (!empty($check_existing_data)) {
            $type = "error";
            $message = "You Already Send This Application !";
        } else {
            $this->emp_model->_table_name = 'tbl_job_appliactions';
            $this->emp_model->_primary_key = 'job_appliactions_id';
            $this->emp_model->save($data);
            // messages for user
            $type = "success";
            $message = "Application Information Successfully Submitted !";
        }
        set_message($type, $message);
        redirect('employee/dashboard');
    }

    public function profile() {
        $data['title'] = "User Profile";
        $employee_id = $this->session->userdata('employee_id');

        //get employee details
        $data['employee_details'] = $this->emp_model->all_emplyee_info($employee_id);

        $data['subview'] = $this->load->view('employee/user_profile', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }
  public function editprofile() {
        $data['title'] = "Edit User Profile";
        $employee_id = $this->session->userdata('employee_id');
        $this->emp_model->_table_name = "countries"; //table name
        $this->emp_model->_order_by = "countryName";
        $data['all_country'] = $this->emp_model->get();
        //get employee details
        $data['employee_details'] = $this->emp_model->all_emplyee_info($employee_id);

        $data['subview'] = $this->load->view('employee/change_profile', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }
	  public function update_profile() {
	  
	        $data = $this->emp_model->array_from_post(array('gender', 'maratial_status', 'father_name', 'nationality',
             'present_address', 'city', 'country_id', 'mobile', 'phone', 'email'));
        //image upload

        if (!empty($_FILES['photo']['name'])) {
            $old_path = $this->input->post('old_path');
            if ($old_path) {
                @unlink($old_path);
            }

            $val = $this->emp_model->uploadImage('photo');
            $val == TRUE || redirect('admin/employee/employees');
            $data['photo'] = $val['path'];
            $data['photo_a_path'] = $val['fullPath'];
        }
		/*  $increment_info = $this->employee_model->check_by(array('employee_id' => $id), 'tbl_employee_salary_details');
        $this->increment_info->_table_name = "tbl_employee_salary_details"; // table name
		 $this->increment_info->_order_by = "employee_salary_id";
         $data['all_increment_info'] = $this->increment_info->get();*/

        // ************* Save into Employee Table 
        $this->emp_model->_table_name = "tbl_employee"; // table name
        $this->emp_model->_primary_key = "employee_id"; // $id
	//	print_r($data);
	 $employee_id =$this->session->userdata('employee_id');	//echo $employee_id;
		    
           // $data['status'] = $this->input->post('status', TRUE);
            $this->emp_model->save($data,$employee_id);
	  
        
        $type = "success";
        $message = lang('profile_updated');
        set_message($type, $message);
        redirect('employee/dashboard/editprofile'); //redirect page
    }
    /*
     * Mailbox Controllers starts ------
     */

    public function inbox() {
        $data['title'] = "Inbox";
        $data['menu'] = array("mailbox" => 1, "inbox" => 1);
        $email = $this->session->userdata('email');

        $data['unread_mail'] = count($this->emp_model->get_inbox_message($email, TRUE));
        $data['get_inbox_message'] = $this->emp_model->get_inbox_message($email);
        $data['subview'] = $this->load->view('employee/inbox', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }

    public function read_inbox_mail($id) {
        $data['menu'] = array("mailbox" => 1, "inbox" => 1);
        $data['title'] = "Inbox Details";
        $this->emp_model->_table_name = 'tbl_inbox';
        $this->emp_model->_order_by = 'inbox_id';
        $data['read_mail'] = $this->emp_model->get_by(array('inbox_id' => $id), true);
        $this->emp_model->_primary_key = 'inbox_id';
        $updata['view_status'] = '1';
        $data['reply'] = 1;
        $this->emp_model->save($updata, $id);
        $data['subview'] = $this->load->view('employee/read_mail', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }

    public function sent() {
        $data['menu'] = array("mailbox" => 1, "sent" => 1);
        $data['title'] = "Sent Item";
        $employee_id = $this->session->userdata('employee_id');
        $data['get_sent_message'] = $this->emp_model->get_sent_message($employee_id);
        $data['subview'] = $this->load->view('employee/sent', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }

    public function read_sent_mail($id) {
        $data['menu'] = array("mailbox" => 1, "sent" => 1);
        $data['title'] = "Sent Details";
        $this->emp_model->_table_name = 'tbl_sent';
        $this->emp_model->_order_by = 'sent_id';
        $data['read_mail'] = $this->emp_model->get_by(array('sent_id' => $id), true);
        $data['subview'] = $this->load->view('employee/read_mail', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }

    public function draft() {
        $data['menu'] = array("mailbox" => 1, "draft" => 1);
        $data['title'] = "Draft";
        $employee_id = $this->session->userdata('employee_id');
        $data['draft_message'] = $this->emp_model->get_draft_message($employee_id);
        $data['subview'] = $this->load->view('employee/draft', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }

    public function trash($action = NULL) {
        $data['menu'] = array("mailbox" => 1, "trash" => 1);
        $employee_id = $this->session->userdata('employee_id');
        if ($action == 'sent') {
            $data['title'] = 'Trash Sent Item';
            $data['trash_view'] = 'sent';
            $data['get_sent_message'] = $this->emp_model->get_sent_message($employee_id, TRUE);
        } elseif ($action == 'draft') {
            $data['title'] = 'Trash Draft Item';
            $data['trash_view'] = 'draft';
            $data['draft_message'] = $this->emp_model->get_draft_message($employee_id, TRUE);
        } else {
            $data['title'] = 'Trash inbox Item';
            $data['trash_view'] = 'inbox';
            $data['get_inbox_message'] = $this->emp_model->get_inbox_message($employee_id, '', TRUE);
        }
        $data['subview'] = $this->load->view('employee/trash', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }

    public function compose($id = NULL, $reply = NULL) {
        $data['title'] = "Compose Mail";
        $data['menu'] = array("mailbox" => 1, "inbox" => 1);
        $this->emp_model->_table_name = 'tbl_employee';
        $this->emp_model->_order_by = 'employee_id';
        $data['get_employee_email'] = $this->emp_model->get_by(array('status' => '1'), FALSE);
        $data['editor'] = $this->data;
        if (!empty($reply)) {
            $data['inbox_info'] = $this->emp_model->check_by(array('inbox_id' => $id), 'tbl_inbox');
        } elseif (!empty($id)) {
            $this->emp_model->_table_name = 'tbl_draft';
            $this->emp_model->_order_by = 'draft_id';
            $data['get_draft_info'] = $this->emp_model->get_by(array('draft_id' => $id), TRUE);
        }
        $data['subview'] = $this->load->view('employee/compose_mail', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }

    public function delete_mail($action, $from_trash = NULL, $v_id = NULL) {
        // get sellected id into inbox email page
        $selected_id = $this->input->post('selected_id', TRUE);
        if (!empty($selected_id)) { // check selected message is empty or not
            foreach ($selected_id as $v_id) {
                if (!empty($from_trash)) {
                    if ($action == 'inbox') {
                        $this->emp_model->_table_name = 'tbl_inbox';
                        $this->emp_model->delete_multiple(array('inbox_id' => $v_id));
                    } elseif ($action == 'sent') {
                        $this->emp_model->_table_name = 'tbl_sent';
                        $this->emp_model->delete_multiple(array('sent_id' => $v_id));
                    } else {

                        $this->emp_model->_table_name = 'tbl_draft';
                        $this->emp_model->delete_multiple(array('draft_id' => $v_id));
                    }
                } else {
                    $value = array('deleted' => 'Yes');
                    if ($action == 'inbox') {
                        $this->emp_model->set_action(array('inbox_id' => $v_id), $value, 'tbl_inbox');
                    } elseif ($action == 'sent') {
                        $this->emp_model->set_action(array('sent_id' => $v_id), $value, 'tbl_sent');
                    } else {
                        $this->emp_model->set_action(array('draft_id' => $v_id), $value, 'tbl_draft');
                    }
                }
            }
            $type = "success";
            $message = 'Meassage Information Permanently Deleted !';
        } elseif (!empty($v_id)) {
            if ($action == 'inbox') {
                $this->emp_model->_table_name = 'tbl_inbox';
                $this->emp_model->delete_multiple(array('inbox_id' => $v_id));
            } elseif ($action == 'sent') {
                $this->emp_model->_table_name = 'tbl_sent';
                $this->emp_model->delete_multiple(array('sent_id' => $v_id));
            } else {
                $this->emp_model->_table_name = 'tbl_draft';
                $this->emp_model->delete_multiple(array('draft_id' => $v_id));
            }
            if ($action == 'inbox') {
                redirect('employee/dashboard/trash/inbox');
            } elseif ($action == 'sent') {
                redirect('employee/dashboard/trash/sent');
            } else {
                redirect('employee/dashboard/trash/draft');
            }
            $type = "success";
            $message = 'Meassage Information Successfully Deleted !';
        } else {
            $type = "error";
            $message = "Please Select a message !";
        }
        set_message($type, $message);
        if ($action == 'inbox') {
            redirect('employee/dashboard/inbox');
        } elseif ($action == 'sent') {
            redirect('employee/dashboard/sent');
        } else {
            redirect('employee/dashboard/draft');
        }
    }

    public function delete_inbox_mail($id) {
        $value = array('deleted' => 'Yes');
        $this->emp_model->set_action(array('inbox_id' => $id), $value, 'tbl_inbox');
        $type = "success";
        $message = 'Meassage Information Successfully Deleted !';
        set_message($type, $message);
        redirect('employee/dashboard/inbox');
    }

    public function send_mail($id = NULL) {

        $discard = $this->input->post('discard', TRUE);

        if (!empty($discard)) {
            redirect('employee/dashboard/inbox');
        }
        $all_email = $this->input->post('to', TRUE);
        // get all email address
        foreach ($all_email as $v_email) {
            $data = $this->emp_model->array_from_post(array('subject', 'message_body'));
            if (!empty($_FILES['attach_file']['name'])) {
                $old_path = $this->input->post('attach_file_path');
                if ($old_path) {
                    unlink($old_path);
                }
                $val = $this->emp_model->uploadAllType('attach_file');
                $val == TRUE || redirect('employee/dashboard/compose');
                // save into send table
                $data['attach_filename'] = $val['fileName'];
                $data['attach_file'] = $val['path'];
                $data['attach_file_path'] = $val['fullPath'];
                // save into inbox table
                $idata['attach_filename'] = $val['fileName'];
                $idata['attach_file'] = $val['path'];
                $idata['attach_file_path'] = $val['fullPath'];
            }
            $data['to'] = $v_email;
            /*
             * Email Configuaration 
             */
            // get company name
            $name = $this->session->userdata('email');
            $info = $data['subject'];
            // set from email
            $from = array($name, $info);
            // set sender email
            $to = $v_email;
            //set subject
            $subject = $data['subject'];
            $data['employee_id'] = $this->session->userdata('employee_id');
            $data['message_time'] = date('Y-m-d H:i:s');
            $draf = $this->input->post('draf', TRUE);
            if (!empty($draf)) {
                $data['to'] = serialize($all_email);

                // save into send 
                $this->emp_model->_table_name = 'tbl_draft';
                $this->emp_model->_primary_key = 'draft_id';
                $this->emp_model->save($data, $id);
                redirect('employee/dashboard/inbox');
            } else {
                // save into send 
                $this->emp_model->_table_name = 'tbl_sent';
                $this->emp_model->_primary_key = 'sent_id';
                $send_id = $this->emp_model->save($data);
                // get mail info by send id to send\
                $this->emp_model->_order_by = 'sent_id';
                $data['read_mail'] = $this->emp_model->get_by(array('sent_id' => $send_id), true);
                // set view page
                $view_page = $this->load->view('employee/read_mail', $data, TRUE);
                $this->load->library('mail');
                $send_email = $this->mail->sendEmail($from, $to, $subject, $view_page);

                // save into inbox table procees 
                $idata['to'] = $data['to'];
                $idata['from'] = $this->session->userdata('email');
                $idata['employee_id'] = $this->session->userdata('employee_id');
                $idata['subject'] = $data['subject'];
                $idata['message_body'] = $data['message_body'];
                $idata['message_time'] = date('Y-m-d H:i:s');

                // save into inbox
                $this->emp_model->_table_name = 'tbl_inbox';
                $this->emp_model->_primary_key = 'inbox_id';
                $this->emp_model->save($idata);
            }
        }
        if ($send_email) {
            $type = "success";
            $message = 'Message Information Suceessfully Send';
            set_message($type, $message);
            redirect('employee/dashboard/sent');
        } else {
            show_error($this->email->print_debugger());
        }
    }

    public function restore($action, $id) {
        $value = array('deleted' => 'No');
        if ($action == 'inbox') {
            $this->emp_model->set_action(array('inbox_id' => $id), $value, 'tbl_inbox');
        } elseif ($action == 'sent') {
            $this->emp_model->set_action(array('sent_id' => $id), $value, 'tbl_sent');
        } else {
            $this->emp_model->set_action(array('draft_id' => $id), $value, 'tbl_draft');
        }
        if ($action == 'inbox') {
            redirect('employee/dashboard/inbox');
        } elseif ($action == 'sent') {
            redirect('employee/dashboard/sent');
        } else {
            redirect('employee/dashboard/draft');
        }
    }

    /*
     * Mailbox Controllers ends ------
     */

    public function change_password() {
        $data['menu'] = array("profile" => 1, "change_password" => 1);
        $data['title'] = "Change Password";
        $data['subview'] = $this->load->view('employee/change_password', $data, TRUE);
        $this->load->view('employee/_layout_main', $data);
    }    

    public function check_employee_password($val) {
        $password = $this->hash($val);
        $check_dupliaction_id = $this->emp_model->check_by(array('password' => $password), 'tbl_employee_login');
        if (empty($check_dupliaction_id)) {
            $result = '<small style="padding-left:10px;color:red;font-size:10px">' . lang('password_do_not_match') . '<small>';
        } else {
            $result = NULL;
        }
        echo $result;
    }

    public function set_password() {
        $employee_login_id = $this->session->userdata('employee_login_id');
        $data['password'] = $this->hash($this->input->post('new_password'));
        $this->emp_model->_table_name = 'tbl_employee_login';
        $this->emp_model->_primary_key = 'employee_login_id';
        $this->emp_model->save($data, $employee_login_id);
        $type = "success";
        $message = lang('password_updated');
        set_message($type, $message);
        redirect('employee/dashboard/change_password'); //redirect page
    }


      public function set_checkin() {
	   $data = $this->emp_model->array_from_post(array('entry_id', 'access_type', 'access_result', 'verif_date', 'live_picture','PersonID','latitude', 'longitude')); //input post  
        // save into tbl expense and return expense id
        $this->emp_model->_table_name = "access_events_data"; // table name
        $this->emp_model->_primary_key = "Event_sno"; // $id
        $expense_id = $this->emp_model->save($data);
	  
    //    $employee_login_id = $this->session->userdata('employee_login_id');
        
        $type = "success";
        $message = "Checkin Success";
        set_message($type, $message);
        redirect('employee/dashboard'); //redirect page
    }

    public function hash($string) {
        return hash('sha512', $string . config_item('encryption_key'));
    }
            
    
     public function set_language($lang) {
        $this->session->set_userdata('lang', $lang);
        redirect($_SERVER["HTTP_REFERER"]);
    }

}
