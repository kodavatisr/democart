<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Global_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('global_model');
        $this->load->model('admin_model');
        $this->load->library('cart');
		 
    }

    public function get_employee_by_designations_id($designation_id) {
        $HTML = NULL;
        $this->admin_model->_table_name = 'tbl_employee';
        $this->admin_model->_order_by = 'designations_id';
        $employee_info = $this->admin_model->get_by(array('designations_id' => $designation_id, 'status' => '1'), FALSE);
        if (!empty($employee_info)) {
            foreach ($employee_info as $v_employee_info) {
                $HTML.="<option value='" . $v_employee_info->employee_id . "'>" . $v_employee_info->first_name . ' ' . $v_employee_info->last_name . "</option>";
            }
        }
        echo $HTML;
    }

    public function check_duplicate_emp_id($val) {
        $check_dupliaction_id = $this->admin_model->check_by(array('employment_id' => $val), 'tbl_employee');

        if (!empty($check_dupliaction_id)) {
            $result = '<small style="padding-left:10px;color:red;font-size:10px">Employee ID Already Exist !<small>';
        } else {
            $result = NULL;
        }
        echo $result;
    }

    public function check_current_password($val) {
        $password = $this->hash($val);
        $check_dupliaction_id = $this->admin_model->check_by(array('password' => $password), 'tbl_user');
        if (empty($check_dupliaction_id)) {
            $result = '<small style="padding-left:10px;color:red;font-size:10px">Your Entered Password Do Not Match !<small>';
        } else {
            $result = NULL;
        }
        echo $result;
    }

    public function hash($string) {
        return hash('sha512', $string . config_item('encryption_key'));
    }

    public function get_item_name_by_id($stock_sub_category_id) {
        $HTML = NULL;
        $this->admin_model->_table_name = 'tbl_stock';
        $this->admin_model->_order_by = 'stock_sub_category_id';
        $stock_info = $this->admin_model->get_by(array('stock_sub_category_id' => $stock_sub_category_id, 'total_stock >=' => '1'), FALSE);
        if (!empty($stock_info)) {
            foreach ($stock_info as $v_stock_info) {
                $HTML.="<option value='" . $v_stock_info->stock_id . "'>" . $v_stock_info->item_name . "</option>";
            }
        }
        echo $HTML;
    }

    public function check_existing_user_name($user_name, $user_id = null) {
        $result = $this->global_model->check_user_name($user_name, $user_id);
        if ($result) {
            echo 'This User Name is Exist!';
        }
    }
	 
 
   public function resetpassword($employee_id)
   { }
    

    public function check_available_leave($employee_id, $start_date = NULL, $end_date = NULL, $leave_category_id = NULL, $applied_calenderdays=NULL) {
         
	  // echo $applied_calenderdays;
	   
	   
	    if (!empty($leave_category_id) && !empty($start_date)) {
		$err='0';
		 $start_explode=explode("-",$start_date);
	 $present_applied_year=$start_explode[0];
		     $total_leavec = $this->global_model->check_by(array('leave_category_id' => $leave_category_id), 'tbl_leave_category'); 
		  $employee_details = $this->global_model->check_by(array('employee_id' => $employee_id), 'tbl_employee');
		  $leave_category_details = $this->global_model->check_by(array('leave_category_id' => $leave_category_id), 'tbl_leave_category');
		   $employee_total_leave_deatils = $this->global_model->check_by(array('employee_id' => $employee_id,'leave_category_id' => $leave_category_id,'year' => $present_applied_year), 'tbl_employee_leave_category');
		   $joing_date= $employee_details->joining_date;
		   $termination_date= $employee_details->termination_date;
		   $present_date=time();
		   if($employee_total_leave_deatils->leave_quota=='' || $employee_total_leave_deatils->leave_quota=='0' )  // check Leaves original quote  is exists
		   {
		   echo "You have No Leave  Left  for $leave_category_details->category "; 
		   $err='1';
		   }else 
		  if($leave_category_details->months_of_service!='0') /// check  leave apply  only after  month of service is reached
		     {
		       $effective_start_Date = date('Y-m-d', strtotime("+".$leave_category_details->months_of_service." months", strtotime($joing_date)));
		       if($present_date>=strtotime($effective_start_Date))
		        { 
		            // echo "Can apply";
		         }else
		         {
		          echo "Sorry, You Cannot apply ".$leave_category_details->category." . you cannot reach ".$leave_category_details->months_of_service." Months  of service ";
				  $err='1';
		         }
		  
		     }else
 			 if($termination_date!='')
			 { 
			   if($leave_category_details->notice_period=='Yes') /// check  leave apply    in notice period
		          {
 				   $diff = abs(strtotime($termination_date) - $present_date);
                     $days = floor($diff / (60 * 60 * 24));
 				     if($days<='30')
		                {
						 echo "Sorry, You Cannot apply ".$leave_category_details->category." . because  you  are in  1 Month Notice Period";
						 $err='1';
						}
						else
						{
						 
						} 
				     }
			   
			  }  if($applied_calenderdays=="0")
			 { 
			  echo "Please select correct dates";
						 $err='1';
			 }  
			 
            $total_leavec = $this->global_model->check_by(array('leave_category_id' => $leave_category_id), 'tbl_leave_category'); 
			  //  $total_leave = $this->global_model->check_by(array('employee_id' => $employee_id,'leave_category_id' => $leave_category_id), 'tbl_employee_leave_category');
				
				
          //  $leave_total = $total_leave->leave_quota;
           $total_leave = $this->global_model->check_by(array('employee_id' => $employee_id,'leave_category_id' => $leave_category_id,'year' => $present_applied_year), 'tbl_employee_leave_category');
				
				
            $leave_total = $total_leave->leave_quota;
		//	echo   (float) $leave_total_intial_used =  $total_leave->intial_used_leave_quota;
			//  echo  (float) $leave_total_used_leaves = $total_leave->used_leaves;
	 // 	echo (float) $total_used leaves=$leave_total_used_leaves + $leave_total_intial_used;
		//	echo $remaining_leaves=$leave_total-$total_used leaves;
			
             $token_leave = $this->db->where(array('employee_id' => $employee_id, 'leave_category_id' => $leave_category_id, 'application_status' => '2','leave_taken_year' => $present_applied_year))->get('tbl_application_list')->result();

            $total_token = 0;
           /* if (!empty($token_leave)) {
                $ge_days = 0;
                $m_days = 0;
                foreach ($token_leave as $v_leave) {
				
				
				   	$start_ldate = new DateTime($v_leave->leave_start_date);
					   $end_ldate = new DateTime($v_leave->leave_end_date);
					// otherwise the  end date is excluded (bug?)
					$end_ldate->modify('+1 day');
					
					$interval_ldate = $end_ldate->diff($start_ldate);
					
					// total days
					$days_ldate = $interval_ldate->days;
					
					// create an iterateable period of date (P1D equates to 1 day)
					$period_ldate = new DatePeriod($start_ldate, new DateInterval('P1D'), $end_ldate);
					
					// best stored as array, so you can add more than one
					 $this->admin_model->_table_name = 'tbl_publicholidays';
                     $this->admin_model->_order_by = 'holiday_created_by';
                     $holiday_info_ldate = $this->admin_model->get_by(array('holiday_status' => 'Yes'), FALSE);
                     if (!empty($holiday_info_ldate)) {
                       foreach ($holiday_info_ldate as $v_holiday_info_ldate) {
                        // $k= $v_stock_info->holiday_date_from  ;
						$hformat_ldate = "Y-m-d";
						 $hbegin_ldate = new DateTime($v_holiday_info_ldate->holiday_date_from);
                          $hend_ldate = new DateTime($v_holiday_info_ldate->holiday_date_to);
						  if($v_holiday_info_ldate->holiday_date_from==$v_holiday_info_ldate->holiday_date_to)
						  {
						  $rangeh_ldate[] =$hbegin_ldate->format($hformat_ldate);
						  }else{
						  
						  
						$hdateRange_ldate = new DatePeriod($hbegin_ldate,new DateInterval('P1D'), $hend_ldate);
			 //	echo "<Pre>";
					//print_r($hdateRange);
						$hrange_ldate = [];
						foreach ($hdateRange_ldate as $hdate_ldate) {
							$rangeh_ldate[] = $hdate_ldate->format($hformat_ldate);
						}
						}
                        }/// for holiday_info
                    }
					//print_r($rangeh);
					$holidays_ldate = $rangeh_ldate;
					
					foreach($period_ldate as $dt_ldate) {
						$curr_ldate = $dt_ldate->format('D');
					 $this->admin_model->_table_name = 'tbl_working_days';
                     $this->admin_model->_order_by = 'working_days_id';
                     $days_info_ldate = $this->admin_model->get_by(array('flag' => 0), FALSE);
						// for the updated question
						if (in_array($dt_ldate->format('Y-m-d'), $holidays_ldate)) {
						 
						 
						  if ($curr_ldate == 'Sat' || $curr_ldate == 'Sun') {} else {
						   $days_ldate--; }
						}
					
					 
						
						
					    foreach ($days_info_ldate as $v_days_info) {
                         if ($curr_ldate == $v_days_info->day_name) {
						 	$days_ldate--;
					 	}
						}
					}
                 
					$ge_days += $days_ldate;
                     $total_token = $ge_days;
                }
            } 
            if (!empty($total_token)) {
                $total_token = $total_token;
            } else {
                $total_token = 0;
            }
            $input_ge_days = 0;
            $input_m_days = 0;
           if (!empty($start_date)) {
			
 						$start = new DateTime($start_date);
					   $end = new DateTime($end_date);
					// otherwise the  end date is excluded (bug?)
					$end->modify('+1 day');
					
					$interval = $end->diff($start);
					
					// total days
					$days = $interval->days;
					
					// create an iterateable period of date (P1D equates to 1 day)
					$period = new DatePeriod($start, new DateInterval('P1D'), $end);
					
					// best stored as array, so you can add more than one
					 $this->admin_model->_table_name = 'tbl_publicholidays';
                     $this->admin_model->_order_by = 'holiday_created_by';
                     $holiday_info = $this->admin_model->get_by(array('holiday_status' => 'Yes'), FALSE);
                     if (!empty($holiday_info)) {
                       foreach ($holiday_info as $v_holiday_info) {
                        // $k= $v_stock_info->holiday_date_from  ;
						$hformat = "Y-m-d";
						 $hbegin = new DateTime($v_holiday_info->holiday_date_from);
                          $hend = new DateTime($v_holiday_info->holiday_date_to);
						  if($v_holiday_info->holiday_date_from==$v_holiday_info->holiday_date_to)
						  {
						  $rangeh[] =$hbegin->format($hformat);
						  }else{
						  
						 $hinterval = new DateInterval('P1D'); // 1 Day
						$hdateRange = new DatePeriod($hbegin, $hinterval, $hend);
			 //	echo "<Pre>";
					//print_r($hdateRange);
						$hrange = [];
						foreach ($hdateRange as $hdate) {
							$rangeh[] = $hdate->format($hformat);
						}
						}
                        }/// for holiday_info
                    }
					//print_r($rangeh);
					$holidays = $rangeh;
					
					foreach($period as $dt) {
						$curr = $dt->format('D');
					 $this->admin_model->_table_name = 'tbl_working_days';
                     $this->admin_model->_order_by = 'working_days_id';
                     $days_info = $this->admin_model->get_by(array('flag' => 0), FALSE);
						// for the updated question
						if (in_array($dt->format('Y-m-d'), $holidays)) {
						 
						 
						  if ($curr == 'Sat' || $curr == 'Sun') {} else {
						   $days--; }
						}
					
					 
						
						
					    foreach ($days_info as $v_days_info) {
                         if ($curr == $v_days_info->day_name) {
						 	$days--;
					 	}
						}
					}


				//echo $days;		
				//   $datetime1 = new DateTime($start_date);
				
				//$datetime2 = new DateTime($end_date);
				
				//$difference = $datetime1->diff($datetime2);
 
               
				$input_total_token=$days;
            }*/
            $taken_with_input = $total_leave->total_used_leaves;;
             $left_leave = $leave_total - $taken_with_input;
			 
			// echo $left_leave."HH".$applied_calenderdays;
			 
            if ($left_leave < $applied_calenderdays) {
			if(@$err=='1') { } else {
			if($leave_total=='0')
			{
			echo "For year  $present_applied_year , You have No Leave  Left  for $total_leavec->category  "; 
			}
			else{
			
			    if($left_leave=='0')
			{
			 echo "For year  $present_applied_year , You don't have leaves  for  $total_leavec->category ";
			}else 
			{
           //   echo $leave_total.$input_total_token."GG".$total_token; 
			     echo "For year  $present_applied_year , You can apply maximum   $left_leave leaves more for  $total_leavec->category  "; 
				 }
             } 
			 }
            }
			
		//	 else{
            //  echo $leave_total.$input_total_token."GG".$total_token;  
			//  }
			 
        } else {
            echo "Please Fill up all required fill to apply ";
        }
    }

}
