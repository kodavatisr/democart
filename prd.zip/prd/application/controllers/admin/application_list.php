<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Application_List extends Admin_Controller {
    public function __construct() {
//  echo $this->session->userdata('employee_id'); echo "GGG";

     parent::__construct();
        $this->load->model('application_model');
		$this->load->model('emp_model');
      //   $val = $this->emp_model->uploadAllType('upload_file');
    }

    public function index() { }

    public function view_application($id) { }

    public function set_action($id) { }

    public function dowload_application_file($id) {
        $appl_info = $this->application_model->check_by(array('application_list_id' => $id), 'tbl_application_list');

        $this->load->helper('download');
        if ($appl_info->upload_file) {
            $down_data = file_get_contents(base_url() . $appl_info->upload_file); // Read the file's contents               
            force_download($appl_info->filename, $down_data);
        } else {
            $type = "error";
            $message = lang('operation_failed');
            set_message($type, $message);
            redirect('admin/application_list/view_application/' . $id);
        }
    }

}
